package com.mindtree.thread;

class ThreadRun implements Runnable{  
public void run(){  
System.out.println("thread is running...");  
}  
  
public static void main(String args[]){  
	ThreadRun m1=new ThreadRun();  
Thread t1 =new Thread(m1);  
t1.start();  
 }  
}



