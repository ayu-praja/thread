package com.mindtree.thread;

public class ThreadExtend extends Thread{
	public void run(){  
		System.out.println("thread is running...");  
		}  
		public static void main(String args[]){  
			ThreadExtend t1=new ThreadExtend();
			t1.start();
	  
		 }  
}
